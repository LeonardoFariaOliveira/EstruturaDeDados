/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lista1.exercicio10;

/**
 *
 * @author leona
 */
public class Main {
    
    /*
    
    Transforme cada uma das extensões pré-fixas em pós-fixas (notação polonesa
    reversa):
    ex. : A+B+C => AB+C+;
   //a A+B-C;
   //R: AB+C-
    
   //b (A+B)*(C-D) / (E*F);
   //R: AB+CD-*EF*/
   
    //c {(A-B)/(C*D)}/E;
    //R: AB-CD*/E/
    
    //d (A+ {[(B-C)*(D-E)+F]/G})/(H-J);
    //R: BC-DE-*F+G/A+HJ-/
    
    
    
    
}
