/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lista1.exercicio2;

/**
 *
 * @author leona
 */
public class Main {
    
    /*
    
    
    Pergunta: Explique o que é um tipo de dado primitivo e o que é um tipo de dado abstrato.
    Dê exemplos. Uma Classe é de que tipo de dados?
    
    Resposta: Tipo de dado primitivo é indivisível, ou seja, uma vez alocado, não pe possível modificar o tipo.
    Exemplo: in, long sheet e etc.
    Tipo de dados abstrato são generalizações que descrevem ações para os dados, classes é um exemplo
    de tipo de dado abstrato.
    
    */
    
    
}
