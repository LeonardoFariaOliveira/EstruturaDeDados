/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lista1.exercicio1;

/**
 *
 * @author leona
 */
public class Main {
    
   /*
    
    
    Pergunta: Explique o que são e qual a utilidade de Estrutura de Dados
    
    Resposta: Estruturas de dados são técnicas utilizadas para organizar/estruturar os dados,
    de modo que seja possível inserir, remover e buscar informações
    
    */
    
}
