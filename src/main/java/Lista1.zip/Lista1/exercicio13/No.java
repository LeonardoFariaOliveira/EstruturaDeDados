/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lista1.exercicio13;

/**
 *
 * @author leona
 */
public class No {
    
    String nome;
    int id;

    public No(String n, int i){
        this.nome = n;
        this.id = i;
    }

    public String tostring(){
        return  "nome: "+nome+" id: "+id;
    }
    
    
}
