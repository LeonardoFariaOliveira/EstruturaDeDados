/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lista1.exercicio9;

/**
 *
 * @author leona
 */
public class Lista {
    
    int indice;
    int valor;
    
    public Lista(int indice, int valor){
        
        this.indice = indice;
        this.valor = valor;
        
    }
    
    public String toString(){
        
        return "Indice: "+this.indice+" Valor: "+this.valor;
    
    }
    
    
    
}
